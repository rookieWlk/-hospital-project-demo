<template>
  <div class="page-header">
    <div>洛杉矶人民医院</div>
  </div>
  <div class="page-container">
    内容
  </div>
</template>
<script setup lang="ts">

</script>

<style scoped lang="scss">
.page-header {
  padding-top: 38px;
  min-height: 300px;
  width: calc(100% - 200px);
  background-color: blue;
}

.page-container {
  padding-top: 38px;
  min-height: 500px;
  width: calc(100% - 200px);
  background-color: red;
}
</style>
